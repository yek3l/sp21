Hi there!

To help students get to know you + make setting up the website easier,
you just need to do a couple of things to fill out your bio.

1. Pick a photo you like in .png format, and add it to this folder with the name "profile_pic".

2. Fill out the bio.yaml file with your responses. Not all the fields are required so fill it out
however you'd like. However. you should provide a name, email, and role at a bare minimum.

3. Rename the file with your first/preferred name.

Once you're done, zip the file and send it to the head TA! It'll be ready to plug into the website.